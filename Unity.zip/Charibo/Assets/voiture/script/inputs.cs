﻿using UnityEngine;
using System.Collections;

public class inputs : MonoBehaviour
{
    public WheelJoint2D RoueArriere;

    JointMotor2D Moteur;

    public float Vitesse;
    public float Couple;

    public float AngleRotationVoiture;

    bool Propulsion = true;

    void Update()
    {
        if (Input.GetAxisRaw("Vertical") > 0)
        {
            if (Propulsion)
            {
                Moteur.motorSpeed = Vitesse * -1;
                Moteur.maxMotorTorque = Couple;
                RoueArriere.motor = Moteur;
            }
        }
        else
        {
            RoueArriere.useMotor = false;
        }

        if (Input.GetAxisRaw("Horizontal") != 0)
        {
            GetComponent<Rigidbody2D>().AddTorque(AngleRotationVoiture * Input.GetAxisRaw("Horizontal") * -1);
        }
    }
}