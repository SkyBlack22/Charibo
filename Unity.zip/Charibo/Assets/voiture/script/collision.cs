﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collision : MonoBehaviour
{
    public AudioSource Death;

    void OnCollisionEnter2D(Collision2D col)
    {
        WheelJoint2D[] Roue = GetComponentsInParent<WheelJoint2D>();

        if (col.gameObject.tag == "Collision")
        {
            foreach(WheelJoint2D wheel in Roue)
            {
                Destroy(wheel);
                Death.Play();
            }
        }
    }
}
