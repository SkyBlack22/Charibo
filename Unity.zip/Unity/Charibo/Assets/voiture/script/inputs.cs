﻿using UnityEngine;
using System.Collections;

public class inputs : MonoBehaviour
{
    public WheelJoint2D RoueAvant;
    public WheelJoint2D RoueArriere;

    JointMotor2D motorFront;
    JointMotor2D motorBack;

    public float speedF;
    public float torqueF;

    public float carRotationSpeed;

    public bool TractionAvant = true;
    public bool TractionArriere = true;

    void Update()
    {
        if (Input.GetAxisRaw("Vertical") > 0)
        {
            if (TractionAvant)
            {
                motorFront.motorSpeed = speedF * -1;
                motorFront.maxMotorTorque = torqueF;
                RoueAvant.motor = motorFront;
            }

            if (TractionArriere)
            {
                motorBack.motorSpeed = speedF * -1;
                motorBack.maxMotorTorque = torqueF;
                RoueArriere.motor = motorBack;
            }
        }
        else
        {
            RoueAvant.useMotor = false;
            RoueArriere.useMotor = false;
        }

        if (Input.GetAxisRaw("Horizontal") != 0)
        {
            GetComponent<Rigidbody2D>().AddTorque(carRotationSpeed * Input.GetAxisRaw("Horizontal") * -1);
        }
    }
}