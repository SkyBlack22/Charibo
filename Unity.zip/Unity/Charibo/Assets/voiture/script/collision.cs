﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class collision : MonoBehaviour
{
    public GameObject Voiture;

    void OnCollisionEnter2D(Collision2D col)
    {
        if(col.gameObject.tag == "Collision")
        {
            Voiture.GetComponent<WheelJoint2D>().connectedBody = null;
            Voiture.GetComponent<WheelJoint2D>().connectedBody = null;
        }
    }
}
